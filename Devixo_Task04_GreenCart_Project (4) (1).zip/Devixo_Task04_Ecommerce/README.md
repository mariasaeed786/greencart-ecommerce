# Devixo Solutions — Task 04
## GreenCart E-Commerce System (PHP + MySQL)

### Features
- Registration, login, logout, password hashing and protected admin area
- Product catalogue, search, category filter, product detail and cart
- Mock checkout creates database orders; order history
- Admin CRUD for products, dashboard stats and table search
- Responsive dark-green UI, input validation, PDO prepared statements, CSRF tokens

### Setup on Windows / XAMPP
1. Install XAMPP and start Apache + MySQL.
2. Copy this folder to `C:\xampp\htdocs\Devixo_Task04_Ecommerce`.
3. Open `http://localhost/phpmyadmin` and import `database.sql`.
4. Visit `http://localhost/Devixo_Task04_Ecommerce/`.
5. Register a normal account.
6. To make it admin: phpMyAdmin → `devixo_ecommerce` → `users` → edit your row → set `role` to `admin`; log out and in again.

Default XAMPP DB credentials in `config.php`: host `localhost`, user `root`, blank password. Update if yours differ.

**Demo note:** Checkout is a mock order flow and does not collect card details. Before public deployment, add HTTPS, rate limiting, email verification, and a security review.
