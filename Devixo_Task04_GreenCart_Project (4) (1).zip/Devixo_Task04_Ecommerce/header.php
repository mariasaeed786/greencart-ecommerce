<?php $pageTitle=$pageTitle??'Shop'; ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($pageTitle)?> | GreenCart</title><link rel="stylesheet" href="assets/style.css"><script defer src="assets/app.js"></script></head><body>
<header class="topbar"><a class="brand" href="index.php"><b>G</b> GreenCart</a><button id="menuBtn" class="menu-btn" aria-label="Open navigation">☰</button><nav id="nav">
<a href="index.php">Shop</a><a href="cart.php">Cart (<?=array_sum($_SESSION['cart']??[])?>)</a>
<?php if(logged_in()): ?><a href="orders.php">My orders</a><?php if(admin_user()):?><a href="admin.php">Admin</a><?php endif; ?><span class="muted"><?=e($_SESSION['user']['name'])?></span><a class="navbtn" href="logout.php">Logout</a>
<?php else: ?><a href="login.php">Login</a><a class="navbtn" href="register.php">Create account</a><?php endif; ?></nav></header><main class="wrap">
<?php if(!empty($_SESSION['flash'])): ?><div class="notice"><?=e($_SESSION['flash']); unset($_SESSION['flash']);?></div><?php endif; ?>
