CREATE DATABASE IF NOT EXISTS devixo_ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE devixo_ecommerce;
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
 role ENUM('user','admin') NOT NULL DEFAULT 'user', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, description TEXT NOT NULL,
 category VARCHAR(80) NOT NULL DEFAULT 'General', price DECIMAL(10,2) NOT NULL DEFAULT 0,
 image_url VARCHAR(500) DEFAULT '', stock INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, total DECIMAL(10,2) NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'Pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, product_id INT NULL,
 product_name VARCHAR(150) NOT NULL, quantity INT NOT NULL, unit_price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);
INSERT INTO products (name,description,category,price,image_url,stock) VALUES
('Wireless Headphones','Comfortable everyday headphones with clear sound.','Electronics',3499,'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',15),
('Smart Watch','A simple smart watch for your daily routine.','Electronics',5999,'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80',10),
('Everyday Backpack','A practical backpack for university and travel.','Accessories',2499,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80',20),
('Desk Lamp','A minimal lamp for a comfortable study space.','Home',1799,'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80',12);
