<?php
declare(strict_types=1);
session_start();
$host='localhost'; $db='devixo_ecommerce'; $user='root'; $pass=''; // Default XAMPP credentials
try {
  $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES=>false
  ]);
} catch (PDOException $e) {
  http_response_code(500);
  exit('Database connection failed. Start MySQL and check config.php settings.');
}
if (!isset($_SESSION['cart'])) $_SESSION['cart']=[];
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in(): bool { return isset($_SESSION['user']['id']); }
function admin_user(): bool { return logged_in() && ($_SESSION['user']['role']??'')==='admin'; }
function require_login(): void { if (!logged_in()) { header('Location: login.php'); exit; } }
function require_admin(): void { if (!admin_user()) { http_response_code(403); exit('403 — Admin access required.'); } }
function token(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_token(): void { if(!hash_equals(token(), (string)($_POST['csrf']??''))) { http_response_code(419); exit('Form expired. Refresh and try again.'); } }
function flash(string $m): void { $_SESSION['flash']=$m; }
function money($n): string { return 'Rs. '.number_format((float)$n,2); }
