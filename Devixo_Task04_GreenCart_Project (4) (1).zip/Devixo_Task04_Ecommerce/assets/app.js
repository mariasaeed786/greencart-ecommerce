const toggle=document.querySelector('#menuBtn'),nav=document.querySelector('#nav');if(toggle&&nav)toggle.addEventListener('click',()=>nav.classList.toggle('open'));
document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm(f.dataset.confirm||'Are you sure?'))e.preventDefault()}));
const search=document.querySelector('#tableSearch');if(search)search.addEventListener('input',()=>{const q=search.value.toLowerCase();document.querySelectorAll('#productTable tbody tr').forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q))});
